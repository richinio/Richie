//
//  ViewController.swift
//  I Am Rich
//
//  Created by Richard Jariashvili on 04/07/2020.
//  Copyright © 2019 Richard Jariashvili. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

